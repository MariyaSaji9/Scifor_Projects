
# importing necessary libraries
import cv2
import mediapipe as mp

from google.protobuf.json_format import MessageToDict

# initializing hands model
mpHands = mp.solutions.hands
hands = mpHands.Hands(static_image_mode=False, model_complexity=1, min_detection_confidence=0.75, min_tracking_confidence=0.75, max_num_hands=2)

# capturing videoframe
cap = cv2.VideoCapture(0)

while True:

    success, img = cap.read() # frames
    img = cv2.flip(img, 1) # flipping frames

     # converting to RGB
    imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    results = hands.process(imgRGB) # processing
    if results.multi_hand_landmarks: # checking hands are present or not
        if len(results.multi_handedness)==2: #checking both hands
            cv2.putText(img, 'Both Hands', (250,50), cv2.FONT_HERSHEY_COMPLEX, 0.9, (0,255,0), 2)
        else:
            for i in results.multi_handedness:
                label = MessageToDict(i)['classification'][0]['label']
                if label == 'Left': # checking left hand
                    cv2.putText(img, label+' Hand', (20,50), cv2.FONT_HERSHEY_COMPLEX, 0.9, (0, 255, 0), 2)
                if label == 'Right': # checking right hand
                    cv2.putText(img, label+' Hand', (460,50), cv2.FONT_HERSHEY_COMPLEX, 0.9, (0, 255, 0), 2)

    # showing the image
    cv2.imshow('Image', img)
    if cv2.waitKey(1) & 0xf==ord('q'):
        break


